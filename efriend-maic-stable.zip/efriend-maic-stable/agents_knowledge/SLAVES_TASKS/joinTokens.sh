cat MICRO_DIALOGUES_SET/aaaCaratula.txt  MICRO_DIALOGUES_SET/*.cod > tokens_all.cod
echo "done"
