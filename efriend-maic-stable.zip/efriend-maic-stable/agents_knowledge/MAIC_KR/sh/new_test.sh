   clingo kr/abiertos.clasp kr/rec.clasp  kr/preguntas_hechas.clasp kr/genera_scrptE.clasp kr/longp_generate.clasp > Adial_new.int
   python outClaspNew.py 
