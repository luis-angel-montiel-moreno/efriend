from .config import paths

print (paths.KR_PATH)
